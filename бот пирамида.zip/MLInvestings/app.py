from loader import bot, ready_code
from aiogram.utils import executor
from handlers.main import *
if __name__ == '__main__':
	executor.start_polling(ready_code)