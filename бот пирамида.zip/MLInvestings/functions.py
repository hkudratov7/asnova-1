import sqlite3
from data.config import *
import asyncio 

conn = sqlite3.connect('data.db', check_same_thread = False)

async def async_query(conn, query):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None, lambda: conn.cursor().execute(query)
        )

async def async_commit(conn):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None, lambda: conn.commit())

def NEW_REFERAL(argument):
    new_referal = f'Hовый реферал!\nВсего рефералов: {referals(argument)}'
    return new_referal

def in_db(id):
    count_of_user_id_in_db = conn.execute(f'''SELECT COUNT(id) FROM users WHERE id = {id}''')
    return count_of_user_id_in_db.fetchall()[0][0]
    
def add(id, **ref_father):
    if ref_father:
        ref_father = ref_father['ref_father']
        conn.execute('''INSERT INTO users(id, ref_father, balance, referals, alltime_subs, fine_count, alltime_get_subs) VALUES(?,?,?,?,?,?,?)''', (id, ref_father, 0,str([]), 0, 0, 0))
        referals_of_ref_father = conn.execute(f'''SELECT referals FROM users WHERE id = ?''', (ref_father,))
        referals_of_ref_father = eval(referals_of_ref_father.fetchall()[0][0])
        referals_of_ref_father.append(id)
        referals_of_ref_father = str(referals_of_ref_father)
        conn.execute(f'''UPDATE users SET referals = ? WHERE id = ?''', (referals_of_ref_father, ref_father,))
        conn.execute('''UPDATE users SET balance = (balance + ?) WHERE id = ?''', (REF_BONUS, ref_father,))
        conn.commit()
    else:
        conn.execute('''INSERT INTO users(id, ref_father, balance, referals, alltime_subs, fine_count, alltime_get_subs) VALUES(?,?,?,?,?,?,?)''', (id, 0, 0, str([]), 0, 0, 0))
        conn.commit()
        
def user_balance(id):
    balance = conn.execute(f'''SELECT balance FROM users WHERE id = ?''', (id,))
    balance = balance.fetchall()[0][0]
    return balance
    
def referals(id):
    count = conn.execute(f'''SELECT referals  FROM users WHERE id = {id}''')
    count = eval(count.fetchall()[0][0])
    count = len(count)
    return count