from aiogram import Dispatcher, Bot
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from functions import *
from data.config import *

bot = Bot(token=TOKEN, parse_mode = 'HTML')
ready_code = Dispatcher(bot, storage = MemoryStorage())