import asyncio
from loader import ready_code
from aiogram import types
from functions import *
from keyboards.users import *
from FSM.all import *
from aiogram.dispatcher import FSMContext
from data.config import *

@ready_code.message_handler(text='/start')
async def start(m: types.Message):
    if in_db(m.from_user.id) < 1:
        argument = m.get_args()
        if (argument is not None) and (argument.isdigit() == True) and (is_user_in_db(argument)) == 1:
            add(m.from_user.id, ref_father = argument)
            await m.answer('Добро пожаловать в бота ML SYSTEM!', reply_markup = ml)
            await bot.send_message(text = NEW_REFERAL(argument), chat_id = argument)
        else:
            add(m.from_user.id)
            await m.answer('Добро пожаловать в бота ML SYSTEM!', reply_markup = ml)
    else:
        await m.answer('Добро пожаловать в бота ML SYSTEM!', reply_markup = ml)

@ready_code.message_handler(text='⚙️ Настройки')
async def settigs(m: types.Message):
	await m.answer('<b>Настройки:</b>', reply_markup = settings)
	
@ready_code.callback_query_handler(text = 'lang')
async def lang(call: types.CallbackQuery):
	await call.answer('Установлен Русский Язык')

@ready_code.message_handler(text = '🎓 Обучение')
async def obuc(m: types.Message):
	await m.answer('📖 <b> Обучение содержит в себе</b>\n\n'
	'- <i> Как привлекать рефералов</i>\n'
	'- <i> Что такое ML</i>\n', reply_markup = link)
	
@ready_code.message_handler(text = '📐 Калькулятор')
async def calc(m: types.Message):
	await m.answer('🤔 Введите сумму для рассчета')
	
	await mat.inpu.set()
	
	
@ready_code.message_handler(state = mat.inpu)
async def math(m: types.Message, state: FSMContext):
	try:
		text1 = int(m.text)
		await state.update_data(text1 = text1)
		await m.answer('😇 <b>Калькулятор</b>\n\n'
    	f'<i>Ваш вклад: {text1}р</i>\n\n'
    	f'За день: {text1/100*10}\n'
    	f'За месяц: {text1/100*10*30}\n'
 	   f'За год: {text1/100*10*365}')
	 
	except:
		await m.answer('Уп-с, произошла ошибка :с')
		await state.finish() 
		
@ready_code.message_handler(text='🧳 Кошелек')
async def balance(m: types.Message):
	await m.answer('👤 <b>Ваш Профиль:</b>\n\n'
    f'💰 Ваш баланс: {user_balance(m.from_user.id)}р.\n'
	f'👥 Кол-во рефералов: {referals(m.from_user.id)}')
	 
@ready_code.message_handler(text='🛎 Реф. система')
async def ref(m: types.Message):
	await m.answer('🏮 <b>Реф линк:</b>\n\n'
    f'https://t.me/configmlbot?start={m.from_user.id}')
    
@ready_code.message_handler(text='🎩 Инвестировать')
async def mla(m: types.Message):
	await m.answer('<b>🎃 Инвестиции:</b>\n'
	'\n<i>Во время Инвестиции  вы получаете 10% каждый день на протяжении 2-ух недель</i>'
	'\nВаше меню вклада:', reply_markup = mlma)
	
@ready_code.callback_query_handler(text='mlm')
async def mlk(call: types.CallbackQuery):
	if user_balance(call.from_user.id) >= 10:
		await call.message.answer('Так, блять, сумму')
		await mlm.summ.set()
	else:
		await call.message.answer('Баланс не соотвествует минимальной сумме вклада')

@ready_code.message_handler(state = mlm.summ)
async def mlkm(m: types.Message, state: FSMContext):
	try:
		text = int(m.text)
		await state.update_data(text = text)
		if text >= user_balance(m.from_user.id):
			await m.answer('<b>Сумма инвестиции больше вашего баланса!</b>')
			await state.finish()
			
		elif text <= user_balance(m.from_user.id) and text <= MINIMAL:
			await m.answer(f'<b>Вы успешно открыли вклад на {text} рублей!</b>') #это типо млм, да :)
			for i in range(0, PROCENT*2):
				await state.finish()
				await asyncio.sleep(86400)
				await async_query(conn, f'''UPDATE users SET balance = (balance + {text/PROCENT}) WHERE id = {m.from_user.id}''')
				await async_commit(conn)
		
		else:
			m.answer('<b>Вы ввели сумму меньше минимального вклада или больше вашего баланса!</b>')

	except:			
		await m.answer('<b>Произошла ошибка!</b>\n',
		'Возможно вы ввели не правильное значение! :(')
				
               
                
                
