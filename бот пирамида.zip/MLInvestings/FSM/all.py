from aiogram.dispatcher.filters.state import State, StatesGroup

class mat(StatesGroup):
	inpu = State()
	 
class mlm(StatesGroup):
	summ = State()
	
