from aiogram.types import ReplyKeyboardMarkup, InlineKeyboardMarkup, \
   InlineKeyboardButton

ml = ReplyKeyboardMarkup(resize_keyboard = True)
ml.row('🎩 Инвестировать', '🛎 Реф. система')
ml.row('🧳 Кошелек', '📐 Калькулятор')
ml.row('🎓 Обучение', '⚙️ Настройки')

settings = InlineKeyboardMarkup()
btn1 = InlineKeyboardButton(text = '📊 Язык', callback_data = 'lang')
settings.add(btn1)

link = InlineKeyboardMarkup()
btn2 = InlineKeyboardButton(text='Читать', url = 'https://telegra.ph/AMG-ML--PARTNYORAM-04-18')
link.add(btn2)

mlma = InlineKeyboardMarkup()
btn3 = InlineKeyboardButton(text='🏮 Вложить', callback_data='mlm')
mlma.add(btn3)